# Fullstack Grocery App (Starter)

Stack: **Spring Boot 3 + JPA + Postgres + React (Vite/TS) + Docker**

## Run (Docker)
```bash
docker compose up --build
```
- Frontend: http://localhost:5173
- Backend:  http://localhost:8080/api/v1
- DB:       localhost:5432 (app/app/appdb)

## Features
- Catalog list/search (basic)
- Cart (session-based, no auth)
- Delivery slot listing + atomic reserve
- Mock checkout (marks order as PAID, clears cart)
- Seed data via `data.sql`

## Useful Endpoints
- `GET /api/v1/catalog`
- `POST /api/v1/cart/add { sessionId, productId, qty }`
- `GET /api/v1/cart/{sessionId}`
- `GET /api/v1/slots`
- `POST /api/v1/orders/place { sessionId, slotId }`

## Next Steps
- Add auth (JWT), addresses, payments
- Add inventory, reviews, loyalty, subscriptions
- Add pagination, filters, images
