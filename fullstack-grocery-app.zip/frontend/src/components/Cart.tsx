import React from 'react'
import { api } from '../api'

type CartItem = { id:number; product:{ id:number; name:string; price:number }; qty:number; priceSnapshot:number }

export default function Cart({ sid }:{ sid:string }){
  const [items, setItems] = React.useState<CartItem[]>([])

  const load = React.useCallback(() => {
    api.get(`/cart/${sid}`).then(r => setItems(r.data))
  }, [sid])

  React.useEffect(() => { load() }, [load])

  const remove = async (id:number) => {
    await api.delete(`/cart/item/${id}`)
    load()
  }

  const subtotal = items.reduce((s, i) => s + i.priceSnapshot * i.qty, 0)

  return (
    <div style={{padding:16}}>
      <h2>Cart</h2>
      {items.length === 0 && <p>Your cart is empty.</p>}
      {items.map(ci => (
        <div key={ci.id} style={{display:'flex', justifyContent:'space-between', padding:'8px 0', borderBottom:'1px solid #eee'}}>
          <div>{ci.product.name} × {ci.qty}</div>
          <div>₹{(ci.priceSnapshot * ci.qty).toFixed(2)}</div>
          <button onClick={() => remove(ci.id)}>Remove</button>
        </div>
      ))}
      <h3>Subtotal: ₹{subtotal.toFixed(2)}</h3>
    </div>
  )
}
