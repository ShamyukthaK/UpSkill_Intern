import React from 'react'
import { api } from '../api'

type Product = { id:number; name:string; description:string; price:number; imageUrl?:string; category?:string }

export default function Catalog({ sid }:{ sid:string }){
  const [items, setItems] = React.useState<Product[]>([])

  React.useEffect(() => {
    api.get('/catalog').then(r => setItems(r.data))
  }, [])

  const add = async (id:number) => {
    await api.post('/cart/add', { sessionId: sid, productId: id, qty: 1 })
    alert('Added to cart')
  }

  return (
    <div style={{padding:16}}>
      <h2>Catalog</h2>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(220px, 1fr))', gap:12}}>
        {items.map(p => (
          <div key={p.id} style={{border:'1px solid #ddd', padding:12, borderRadius:6}}>
            <strong>{p.name}</strong>
            <div>₹{p.price}</div>
            <small>{p.category}</small>
            <p style={{minHeight:40}}>{p.description}</p>
            <button onClick={() => add(p.id)}>Add to cart</button>
          </div>
        ))}
      </div>
    </div>
  )
}
