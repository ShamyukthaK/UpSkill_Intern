import React from 'react'
import { api } from '../api'

type Slot = { id:number; date:string; startTime:string; endTime:string; capacityTotal:number; capacityReserved:number }

export default function Checkout({ sid }:{ sid:string }){
  const [slots, setSlots] = React.useState<Slot[]>([])
  const [slotId, setSlotId] = React.useState<number|undefined>(undefined)
  const [status, setStatus] = React.useState<string>('')

  React.useEffect(() => { api.get('/slots').then(r => setSlots(r.data)) }, [])

  const place = async () => {
    if (!slotId) { alert('Select a slot'); return }
    try {
      const res = await api.post('/orders/place', { sessionId: sid, slotId })
      setStatus(`Order placed! Order ID: ${res.data.id}, Total: ₹${res.data.total}`)
    } catch (e:any) {
      alert(e?.response?.data?.message || 'Order failed')
    }
  }

  return (
    <div style={{padding:16}}>
      <h2>Checkout</h2>
      <h3>Select Delivery Slot</h3>
      <div style={{display:'flex', gap:8, flexWrap:'wrap'}}>
        {slots.map(s => {
          const full = s.capacityReserved >= s.capacityTotal
          return (
            <button key={s.id} disabled={full}
              onClick={() => setSlotId(s.id)}
              style={{border: slotId===s.id?'2px solid black':'1px solid #ccc', padding:8, borderRadius:6}}>
              {s.date} {s.startTime}-{s.endTime} ({s.capacityReserved}/{s.capacityTotal})
            </button>
          )
        })}
      </div>
      <div style={{marginTop:16}}>
        <button onClick={place}>Place Order (Mock Paid)</button>
      </div>
      {status && <p style={{marginTop:12}}>{status}</p>}
    </div>
  )
}
