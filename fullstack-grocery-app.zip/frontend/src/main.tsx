import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import Catalog from './components/Catalog'
import Cart from './components/Cart'
import Checkout from './components/Checkout'

function App() {
  // simple session id for demo
  const sid = React.useMemo(() => localStorage.getItem('sid') || (() => {
    const s = Math.random().toString(36).slice(2);
    localStorage.setItem('sid', s);
    return s;
  })(), []);

  return (
    <BrowserRouter>
      <nav style={{display:'flex', gap:12, padding:12, borderBottom:'1px solid #ccc'}}>
        <Link to="/">Catalog</Link>
        <Link to="/cart">Cart</Link>
        <Link to="/checkout">Checkout</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Catalog sid={sid} />} />
        <Route path="/cart" element={<Cart sid={sid} />} />
        <Route path="/checkout" element={<Checkout sid={sid} />} />
      </Routes>
    </BrowserRouter>
  )
}

ReactDOM.createRoot(document.getElementById('root')!).render(<App />)
