-- Seed products
INSERT INTO product (name, description, price, image_url, category) VALUES
('Milk 1L','Fresh cow milk', 62.00, '', 'Dairy'),
('Basmati Rice 5kg','Premium long grain', 599.00, '', 'Grains'),
('Sunflower Oil 1L','Refined edible oil', 145.00, '', 'Oil'),
('Eggs 12 pcs','Farm fresh eggs', 78.00, '', 'Poultry'),
('Apples 1kg','Kashmiri apples', 180.00, '', 'Fruits');

-- Seed slots (sample, adjust times)
INSERT INTO delivery_slot (date, start_time, end_time, capacity_total, capacity_reserved) VALUES
(current_date, '10:00', '12:00', 20, 0),
(current_date, '12:00', '14:00', 20, 0),
(current_date, '16:00', '18:00', 20, 0);
