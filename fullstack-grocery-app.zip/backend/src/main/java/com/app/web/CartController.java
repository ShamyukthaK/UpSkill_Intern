package com.app.web;

import com.app.model.CartItem;
import com.app.service.CartService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController @RequestMapping("/api/v1/cart") @RequiredArgsConstructor
public class CartController {
  private final CartService service;

  @GetMapping("/{sessionId}")
  public List<CartItem> get(@PathVariable String sessionId) {
    return service.getCart(sessionId);
  }

  @PostMapping("/add")
  public CartItem add(@RequestBody AddReq req) {
    return service.addToCart(req.sessionId, req.productId, req.qty);
  }

  @DeleteMapping("/item/{id}")
  public void remove(@PathVariable Long id) { service.removeItem(id); }

  @Data public static class AddReq { public String sessionId; public Long productId; public int qty; }
}
