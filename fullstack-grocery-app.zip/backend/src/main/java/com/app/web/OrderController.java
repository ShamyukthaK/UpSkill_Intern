package com.app.web;

import com.app.model.OrderEntity;
import com.app.service.OrderService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/v1/orders") @RequiredArgsConstructor
public class OrderController {
  private final OrderService service;

  @PostMapping("/place")
  public OrderEntity place(@RequestBody PlaceReq req) {
    return service.placeOrder(req.sessionId, req.slotId);
  }

  @Data public static class PlaceReq { public String sessionId; public Long slotId; }
}
