package com.app.web;

import com.app.model.DeliverySlot;
import com.app.service.SlotService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController @RequestMapping("/api/v1/slots") @RequiredArgsConstructor
public class SlotController {
  private final SlotService service;

  @GetMapping
  public List<DeliverySlot> all() { return service.all(); }

  @PostMapping("/{slotId}/reserve")
  public DeliverySlot reserve(@PathVariable Long slotId) { return service.reserve(slotId); }
}
