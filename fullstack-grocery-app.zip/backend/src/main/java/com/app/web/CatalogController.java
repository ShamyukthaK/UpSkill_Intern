package com.app.web;

import com.app.model.Product;
import com.app.service.CatalogService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController @RequestMapping("/api/v1/catalog") @RequiredArgsConstructor
public class CatalogController {
  private final CatalogService service;

  @GetMapping
  public List<Product> list(@RequestParam(required=false) String q,
                            @RequestParam(required=false) String category) {
    return service.list(q, category);
  }

  @PostMapping
  public Product create(@RequestBody Product p) { return service.create(p); }
}
