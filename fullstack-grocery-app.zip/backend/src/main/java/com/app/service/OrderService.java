package com.app.service;

import com.app.model.*;
import com.app.repo.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service @RequiredArgsConstructor
public class OrderService {
  private final OrderRepo orderRepo;
  private final OrderItemRepo orderItemRepo;
  private final CartService cartService;
  private final SlotService slotService;

  @Transactional
  public OrderEntity placeOrder(String sessionId, Long slotId) {
    // reserve slot (atomic)
    slotService.reserve(slotId);

    var cart = cartService.getCart(sessionId);
    if (cart.isEmpty()) throw new IllegalStateException("Cart empty");

    BigDecimal subtotal = cartService.subtotal(sessionId);
    BigDecimal taxes = subtotal.multiply(BigDecimal.valueOf(0.05));
    BigDecimal deliveryFee = subtotal.compareTo(BigDecimal.valueOf(499)) >= 0 ? BigDecimal.ZERO : BigDecimal.valueOf(40);
    BigDecimal total = subtotal.add(taxes).add(deliveryFee);

    OrderEntity order = OrderEntity.builder()
      .sessionId(sessionId)
      .slotId(slotId)
      .status("PAID") // mocked as paid
      .subtotal(subtotal)
      .taxes(taxes)
      .deliveryFee(deliveryFee)
      .total(total)
      .createdAt(Instant.now())
      .build();
    order = orderRepo.save(order);

    List<OrderItem> items = new ArrayList<>();
    for (CartItem ci : cart) {
      OrderItem oi = OrderItem.builder()
        .order(order)
        .product(ci.getProduct())
        .qty(ci.getQty())
        .price(ci.getPriceSnapshot())
        .lineTotal(ci.getPriceSnapshot().multiply(BigDecimal.valueOf(ci.getQty())))
        .build();
      items.add(orderItemRepo.save(oi));
    }
    order.setItems(items);
    cartService.clear(sessionId);
    return orderRepo.save(order);
  }
}
