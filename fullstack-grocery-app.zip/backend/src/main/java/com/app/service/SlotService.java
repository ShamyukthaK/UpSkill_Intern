package com.app.service;

import com.app.model.DeliverySlot;
import com.app.repo.DeliverySlotRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service @RequiredArgsConstructor
public class SlotService {
  private final DeliverySlotRepo repo;

  public List<DeliverySlot> all() { return repo.findAll(); }

  @Transactional
  public DeliverySlot reserve(Long slotId) {
    DeliverySlot s = repo.lockById(slotId).orElseThrow();
    if (s.getCapacityReserved() >= s.getCapacityTotal()) {
      throw new IllegalStateException("Slot full");
    }
    s.setCapacityReserved(s.getCapacityReserved()+1);
    return repo.save(s);
  }
}
