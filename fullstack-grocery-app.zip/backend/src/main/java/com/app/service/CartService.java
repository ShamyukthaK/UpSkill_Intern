package com.app.service;

import com.app.model.CartItem;
import com.app.model.Product;
import com.app.repo.CartItemRepo;
import com.app.repo.ProductRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service @RequiredArgsConstructor
public class CartService {
  private final CartItemRepo cartRepo;
  private final ProductRepo productRepo;

  public List<CartItem> getCart(String sessionId) {
    return cartRepo.findBySessionId(sessionId);
  }

  @Transactional
  public CartItem addToCart(String sessionId, Long productId, int qty) {
    Product p = productRepo.findById(productId).orElseThrow();
    CartItem ci = CartItem.builder()
            .sessionId(sessionId)
            .product(p)
            .qty(qty)
            .priceSnapshot(p.getPrice())
            .build();
    return cartRepo.save(ci);
  }

  public void removeItem(Long cartItemId) {
    cartRepo.deleteById(cartItemId);
  }

  public void clear(String sessionId) { cartRepo.deleteBySessionId(sessionId); }

  public BigDecimal subtotal(String sessionId) {
    return getCart(sessionId).stream()
      .map(ci -> ci.getPriceSnapshot().multiply(BigDecimal.valueOf(ci.getQty())))
      .reduce(BigDecimal.ZERO, BigDecimal::add);
  }
}
