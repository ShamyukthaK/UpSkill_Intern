package com.app.service;

import com.app.model.Product;
import com.app.repo.ProductRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service @RequiredArgsConstructor
public class CatalogService {
  private final ProductRepo repo;

  public List<Product> list(String q, String category) {
    if (q != null && !q.isBlank()) return repo.findByNameContainingIgnoreCase(q);
    if (category != null && !category.isBlank()) return repo.findByCategoryIgnoreCase(category);
    return repo.findAll();
  }

  public Product create(Product p) { return repo.save(p); }
}
