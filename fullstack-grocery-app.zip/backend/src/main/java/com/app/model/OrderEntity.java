package com.app.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;

@Entity @Table(name="orders")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class OrderEntity {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private String sessionId;
  private Long slotId;
  private String status; // CREATED, PAID, PACKED, OUT_FOR_DELIVERY, DELIVERED, CANCELLED
  private BigDecimal subtotal;
  private BigDecimal taxes;
  private BigDecimal deliveryFee;
  private BigDecimal total;
  private Instant createdAt;
  @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
  private List<OrderItem> items = new ArrayList<>();
}
