package com.app.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;

@Entity @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class CartItem {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private String sessionId; // simple: use sessionId instead of auth for starter
  @ManyToOne
  private Product product;
  private int qty;
  private BigDecimal priceSnapshot;
}
