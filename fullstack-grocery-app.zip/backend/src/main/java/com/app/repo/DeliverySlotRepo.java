package com.app.repo;

import com.app.model.DeliverySlot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import jakarta.persistence.LockModeType;
import java.util.Optional;

public interface DeliverySlotRepo extends JpaRepository<DeliverySlot, Long> {
  @Lock(LockModeType.PESSIMISTIC_WRITE)
  @Query("select s from DeliverySlot s where s.id = :id")
  Optional<DeliverySlot> lockById(@Param("id") Long id);
}
