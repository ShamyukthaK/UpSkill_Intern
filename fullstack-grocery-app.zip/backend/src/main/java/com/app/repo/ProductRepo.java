package com.app.repo;

import com.app.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProductRepo extends JpaRepository<Product, Long> {
  List<Product> findByNameContainingIgnoreCase(String q);
  List<Product> findByCategoryIgnoreCase(String c);
}
